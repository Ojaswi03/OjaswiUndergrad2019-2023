#ifndef Ojaswi_H
#define Ojaswi_H
 
float get_running_ratio();

int random_in_range( int lower_bound, int upper_bound);

int get_vowel_count( char *array, int arraySize);

#endif
